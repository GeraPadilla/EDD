/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Eva3_1_Ordenamientos;

/**
 *
 * @author Asus
 */
public class Eva3_1_Ordenamientos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] arreglin = new int[20];
        long ini, fin;
        llenar(arreglin);
        imprimir(arreglin);
        ini = System.nanoTime();
        selectionSort(arreglin);
        fin = System.nanoTime();
        imprimir(arreglin);
        System.out.println("Tiempo" + (fin - ini));
        System.out.println("------------otro arreglin jaja------");
        int[] arreglin2 = new int[20];
        llenar(arreglin2);
        imprimir(arreglin2);
        ini = System.nanoTime();
        insertionSort(arreglin2);
        fin = System.nanoTime();
        imprimir(arreglin2);
        System.out.println("Tiempo;" + (fin - ini));
        System.out.println("------------otro arreglin♥ß jaja------");
        int[] arreglin3 = new int[20];
        llenar(arreglin3);
        imprimir(arreglin3);
        ini = System.nanoTime();
        bubbleSort(arreglin3);
        fin = System.nanoTime();
        imprimir(arreglin3);
        System.out.println("Tiempo;" + (fin - ini));
        System.out.println("------------otro arreglin♥ß jaja------");
        int[] arreglin4 = new int[20];
        llenar(arreglin4);
        imprimir(arreglin4);
        ini = System.nanoTime();
        quickSort(arreglin4);
        fin = System.nanoTime();
        imprimir(arreglin4);
        System.out.println("Tiempo;" + (fin - ini));
    }//hace mas comparaciones menos operaciones On2

    public static void selectionSort(int[] arreglo) {
        int min;
        int aux = 0;
        for (int i = 0; i < arreglo.length - 1; i++) {
            min = i;
            for (int j = i + 1; j < arreglo.length; j++) {
                if (arreglo[min] > arreglo[j]) {
                    min = j;
                }
            }
            aux = arreglo[i];
            arreglo[i] = arreglo[min];
            arreglo[min] = aux;
        }
    }//mas intercambios menos comparaciones

    public static void insertionSort(int[] arreglo) {
        for (int i = 1; i < arreglo.length; i++) {
            int valorActual = arreglo[i];
            int j = i - 1;
            while ((j >= 0) && (arreglo[j] > valorActual)) {
                arreglo[j + 1] = arreglo[j];
                j = j - 1;
            }
            arreglo[j + 1] = valorActual;
        }
    }

    public static void bubbleSort(int[] arreglo) {
        for (int i = 0; i < arreglo.length ; i++) {
            for (int j = 0; j < arreglo.length-1; j++) {
                /*  if (arreglo[i] > arreglo[i + 1]) {
                    int iTemp = arreglo[i];
                    arreglo[i] = arreglo[i + 1];
                    arreglo[i + 1] = iTemp;

                }*/
                if (arreglo[j] > arreglo[j + 1]) {
                    int iTemp = arreglo[j];
                    arreglo[j] = arreglo[j + 1];
                    arreglo[j + 1] = iTemp;

                }
            }
        }
    }

    public static void quickSort(int[] arreglo) {
        quickSortRec(arreglo, 0, arreglo.length - 1);
    }

    private static void quickSortRec(int[] arreglo, int ini, int fin) {
        //detener
        if ((ini >= 0) && (ini<fin)) {
            int iPiv = ini;
            int iTemp;
            int too_big = ini + 1;
            int too_small = fin;
            while (too_big < too_small) {
                while (((too_big) < fin) && (arreglo[too_big] < arreglo[iPiv])) {
                    too_big++;
                }
                while (((too_small) > (ini + 1)) && (arreglo[too_small] > arreglo[iPiv])) {
                    too_small--;
                }

                if (too_big < too_small) {//no hay cruce
                    iTemp = arreglo[too_big];
                    arreglo[too_big] = arreglo[too_small];
                    arreglo[too_small] = iTemp;
                }

            }
            iTemp = arreglo[iPiv];
            arreglo[iPiv] = arreglo[too_small];
            arreglo[too_small] = iTemp;
            quickSortRec(arreglo, ini, too_small-1);//izq
            quickSortRec(arreglo, too_small+1, fin);//der    
        }

    }

    public static void llenar(int[] arreglo) {
        for (int i = 0; i < arreglo.length; i++) {
            arreglo[i] = (int) (Math.random() * 100);
        }
    }

    public static void imprimir(int[] arreglo) {
        for (int i = 0; i < arreglo.length; i++) {
            System.out.print("[" + arreglo[i] + "]");
        }
        System.out.println("");
    }

}
