/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_10_stack;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asus
 */
public class Eva2_10_Stack {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        Pila apilada = new Pila();
        apilada.push(new Nodo(100));
        apilada.push(new Nodo(90));
        apilada.push(new Nodo(80));
        apilada.push(new Nodo(70));
        apilada.push(new Nodo(50));
            
        apilada.print();
        System.out.println("Se revisó la cima, ahora mismo es " + apilada.peek());
        try {

            System.out.println("la cima " + apilada.pop()+" se borrará");
        } catch (Exception ex) {
            Logger.getLogger(Eva2_10_Stack.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Se revisó la cima, ahora mismo es  "+apilada.peek());
    }

}
