
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner tecladin=new Scanner(System.in);
        System.out.println("Ingrese hasta donde primojaja");
        int n=tecladin.nextInt();
        
    }
   // public static boolean primin_feo(int n){
        
   // }
    //i <- 2 a raiz n
    //big O, tiempo maximo posible, el peor caso
    //big Omega, tiempo minimo, el mejor caso
    //big Tetha, ambos limites, el caso promedio
}
