/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_11_queue;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asus
 */
public class Eva2_11_Queue {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //agregar al final, quitar y leer el inicio
        Cola colada=new Cola();
        colada.push(new Nodo(100));
        colada.push(new Nodo(90));
        colada.push(new Nodo(80));
        colada.push(new Nodo(70));
        colada.push(new Nodo(50));
        colada.print();
        try {
            System.out.println("el inicio seria "+colada.peek());
        } catch (Exception ex) {
            Logger.getLogger(Eva2_11_Queue.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
