/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_15_arraylist;

import java.util.ArrayList;

/**
 *
 * @author Asus
 */
public class Eva2_15_Arraylist {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Integer> MiArray=new ArrayList<Integer>();
        MiArray.add(420);
        MiArray.add(69);
        MiArray.add(911);
        MiArray.add(300);
        MiArray.add(0);
        MiArray.add(900);
    }
    
}
