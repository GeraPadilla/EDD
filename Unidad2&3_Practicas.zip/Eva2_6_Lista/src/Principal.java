/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Nodo nObj1=new Nodo();
        nObj1.enterin=420;
        nObj1.Nsig=new Nodo();
        nObj1.Nsig.enterin=69;
        nObj1.Nsig.Nsig=new Nodo();
        nObj1.Nsig.Nsig.enterin=911;
        System.out.println(nObj1.enterin);
        System.out.println(nObj1.Nsig.enterin);
        System.out.println(nObj1.Nsig.Nsig.enterin);
    }
    
    
}

class Nodo{
    int enterin;
    Nodo Nsig;
    
}