/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_13_arbolbinario;

/**
 *
 * @author Asus
 */
public class NodoDoble {

    private int enterin;
    private NodoDoble izq;
    private NodoDoble der;

    public NodoDoble() {
        this.izq = null;
        this.der=null;
    }

    public NodoDoble(int enterin) {
        this.enterin = enterin;
        this.izq = null;
        this.der=null;
    }

    public int getEnterin() {
        return enterin;
    }

    public void setEnterin(int enterin) {
        this.enterin = enterin;
    }

    public NodoDoble getIzq() {
        return izq;
    }

    public void setIzq(NodoDoble izq) {
        this.izq = izq;
    }
    public NodoDoble getDer(){
        return der;
    }
    public void setDer(NodoDoble der){
        this.der=der;
    }

}
