/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_13_arbolbinario;

/**
 *
 * @author Asus
 */
public class Eva2_13_ArbolBinario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Arbol arbolin=new Arbol();
        arbolin.AgregarNodo(new NodoDoble(420));
        arbolin.AgregarNodo(new NodoDoble(69));
        arbolin.AgregarNodo(new NodoDoble(911));
        arbolin.AgregarNodo(new NodoDoble(300));
        arbolin.AgregarNodo(new NodoDoble(100));
        arbolin.imprimirInOrder();
        System.out.println("");
        System.out.println("------------------------------------------");
        arbolin.imprimirPostOrder();
        System.out.println("");
        System.out.println("------------------------------------------");
        arbolin.imprimirPreOrder();
    }
    
}
