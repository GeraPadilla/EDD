/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_13_arbolbinario;

import com.sun.org.apache.xalan.internal.xsltc.compiler.sym;

/**
 *
 * @author Asus
 */
public class Arbol {

    private NodoDoble root;

    public Arbol() {
        root = null;
    }

    public void AgregarNodo(NodoDoble nuevo) {
        AgregarNodoRec(root, nuevo);
    }

    private void AgregarNodoRec(NodoDoble actual, NodoDoble nuevo) {
        if (root == null) {
            root = nuevo;
        } else {
            if (nuevo.getEnterin() > actual.getEnterin()) {//mayor ->
                if (actual.getDer() == null) {//vacio
                    actual.setDer(nuevo);
                } else {//ya hay un nodo jajaxd
                    AgregarNodoRec(actual.getDer(), nuevo);
                }
            } else if (nuevo.getEnterin() < actual.getEnterin()) {//menor<-
                if (actual.getIzq() == null) {//vacio
                    actual.setIzq(nuevo);
                } else {//ya hay un nodo jajaxd
                    AgregarNodoRec(actual.getIzq(), nuevo);
                }
            } else {//igual
                System.out.println("no carnal eso ya existe");
            }
        }
    }

    public void imprimirPostOrder() {
        PostOrder(root);
    }

    private void PostOrder(NodoDoble actual) { //leer izq, der y luego imprimir
        if (actual != null) {
            PostOrder(actual.getIzq());
            PostOrder(actual.getDer());
            System.out.print(actual.getEnterin() + "-");
        }

    }

    public void imprimirPreOrder() {
        PreOrder(root);
    }

    private void PreOrder(NodoDoble actual) { //leer izq, der y luego imprimir
        if (actual != null) {
            System.out.print(actual.getEnterin() + "-");
            PreOrder(actual.getIzq());
            PreOrder(actual.getDer());

        }

    }

    private void InOrder(NodoDoble actual) {
        if (actual != null) {

            InOrder(actual.getIzq());
            System.out.print(actual.getEnterin() + "-");
            InOrder(actual.getDer());

        }
    }
    public void imprimirInOrder(){
        InOrder(root);
    }
}
