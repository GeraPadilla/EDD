/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva3_2_comparator;

import java.util.Comparator;
import java.util.LinkedList;

/**
 *
 * @author Asus
 */
public class Eva3_2_Comparator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LinkedList<Integer> MiArray = new LinkedList<Integer>();
        for (int i = 0; i < 15; i++) {
            MiArray.add((int) (Math.random() * 100));
        }
        System.out.println(MiArray);
        Comparator c = new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                Integer val1, val2;
                val1 = (Integer) o1;
                val2 = (Integer) o2;
                int resu;//0,-,+ si es 0, es igual, si es + es mayor y - menos
                return resu = val1 - val2;
            }

        };
        MiArray.sort(c);
        System.out.println(MiArray);
        System.out.println("--------------------------------------♥--------------------------------");
        LinkedList<String> miaLista = new LinkedList<String>();
        miaLista.add("holi");
        miaLista.add("arbolin");
        miaLista.add("jaja");
        miaLista.add("xd");
        miaLista.add("mlg");
        miaLista.add("doritos");
        miaLista.add("!!");
        Comparator compStr = new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                String cade = (String) o1;
                String cade2 = (String) o2;
                char c1 = cade.charAt(0);
                char c2 = cade2.charAt(0);
                return c1 - c2;
            }
        };
        System.out.println(miaLista);
        miaLista.sort(compStr);
        System.out.println(miaLista);

    }

}
