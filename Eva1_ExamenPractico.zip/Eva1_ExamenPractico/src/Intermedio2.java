
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Asus
 */
public class Intermedio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] array = new int[15];
        Scanner soli = new Scanner(System.in);
        Scanner cic = new Scanner(System.in);
        int ciclo = 1;
        for (int i = 0; i < array.length; i++) {
            array[i] = (int) ((Math.random() * 100) + 1);
        }
        while (ciclo == 1) {
            int vacio = 0, borra = 0;
            for (int i = 0; i < array.length; i++) {
                if (array[i] == borra) {
                    array[i] = 0;
                    vacio += 1;
                }
                if (array[i] != 0) {
                    System.out.print("[" + array[i] + "] ");
                }
            }
            for (int i = 0; i < vacio; i++) {
                System.out.print("[ ] ");
            }
            System.out.println("\nInserta un valor a borrar");
            borra = soli.nextInt();
            soli.nextLine();
            for (int i = 0; i < array.length; i++) {
                if (array[i] == borra) {
                    array[i] = 0;
                    vacio += 1;
                }
                if (array[i] != 0) {
                    System.out.print("[" + array[i] + "] ");
                }
            }
            for (int i = 0; i < vacio; i++) {
                System.out.print("[ ] ");
            }
            System.out.println("");
            System.out.println("¿Quieres borrar otro valor?\n1: SI \nCualquier otro número:NO");
            ciclo = cic.nextInt();
            cic.nextLine();
        }
    }

}
