
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Asus
 */
public class Principiante6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) { //n6 principiantes
        // TODO code application logic here
        int[][] matriza = new int[4][4];
        Scanner teclazo = new Scanner(System.in);
        for (int i = 0; i < matriza.length; i++) {
            for (int j = 0; j < matriza[i].length; j++) {
                System.out.println("Inserta el valor [" + (i + 1) + "," + (j + 1) + "]");
                matriza[i][j] = teclazo.nextInt();
            }
        }
        for (int i = 0; i < matriza.length; i++) {
            for (int j = 0; j < matriza[i].length; j++) {
                System.out.print("[" + matriza[i][j] + "]");
            }
            System.out.println("");
        }
        System.out.println("-----------------------------------------------------------------------------");
        double[] promfila = new double[4];
        double[] promcolumna = new double[4];
        double sumafila=0,sumacolumna = 0;
        for (int i = 0; i < matriza.length; i++) {
            for (int j = 0; j < matriza[i].length; j++) {
                sumafila = sumafila + matriza[i][j];
                sumacolumna=sumacolumna+matriza[j][i];
            }
            promfila[i] = sumafila / matriza[i].length;
            promcolumna[i]=sumacolumna/matriza[i].length;
            System.out.println("El promedio de la fila " + (i + 1) + " es " +promfila[i]);
            System.out.println("El promedio de la columna " + (i + 1) + " es " +promcolumna[i]);
            sumafila=0;
            sumacolumna=0;
            if (promfila[i]==promcolumna[i]) {
                    System.out.println("-------El promedio de la fila-columna "+(i+1)+" es igual, "+promfila[i]+"-------");
            }
        }
        

    }

}
