/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class Principiante1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) { //principiante n1
        // TODO code application logic here
        int[] Arreglin = new int[15];
        int pareja;
        for (int i = 0; i < Arreglin.length; i++) {
            pareja = (int) (Math.random() * 100) + 1;
            if (pareja % 2 == 0) {
                Arreglin[i] = pareja;
            }
            for (int j = 0; j < i; j++) {
                if (Arreglin[i] == Arreglin[j]) {
                    i--;
                }
            }
           
        }
        for (int i : Arreglin) {
            System.out.println(i);
        }
       

    }

}
