/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int Arreglo[][] = new int[3][4];
        System.out.println("Dirección de Arreglo " + Arreglo);
        System.out.println("Tamaño del arreglo " + Arreglo.length);

        System.out.println("Dirección de Arreglo[0] " + Arreglo[0]);
        System.out.println("Tamaño del arreglo[0] " + Arreglo[0].length);

        System.out.println("Valor de Arreglo[0][0] " + Arreglo[0][0]);
        System.out.println("Valor del arreglo[0][1] " + Arreglo[0][1]);
    }

}
