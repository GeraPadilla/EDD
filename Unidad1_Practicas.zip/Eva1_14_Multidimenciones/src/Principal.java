/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int aMatriz[][]=new int[2][3];
        int bMatriz[][];
        bMatriz=new int[3][];
        bMatriz[0]=new int[10];
        bMatriz[1]=new int[100];
        bMatriz[2]=new int[24];
        for (int i = 0; i < bMatriz.length; i++) {
             for (int j = 0; j < bMatriz[i].length; j++) {
                bMatriz[i][j]=(int)(Math.random()*100)+1;
            }
        }
        for (int i = 0; i < bMatriz.length; i++) {
             for (int j = 0; j < bMatriz[i].length; j++) {
                 System.out.print("["+bMatriz[i][j]+"]");
            }
             System.out.println("");
        }
    }
    
}
