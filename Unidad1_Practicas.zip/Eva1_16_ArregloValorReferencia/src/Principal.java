/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int Arreglaso[]=new int[5];
        System.out.println(Arreglaso);
        llenado(Arreglaso);
        madrear(Arreglaso);
        System.out.println(Arreglaso);
        imprenta(Arreglaso);        
    }
    public static void llenado(int[] arre){
        for (int i = 0; i < arre.length; i++) {
            arre[i]=(int)(Math.random()*100);
        }
        imprenta(arre);
}
      public static void imprenta(int[] arre) {
        for (int i = 0; i < arre.length; i++) {
            System.out.print("["+arre[i]+"]");
        }
        System.out.println("");
    }
      public static void madrear(int[] arre){
          arre=new int[100];
          System.out.println(arre);
      }
}