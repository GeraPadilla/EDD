/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int aiDatos[];
        int tama=100;
        aiDatos=new int[tama];
        for (int i = 0; i < aiDatos.length; i++) {
            aiDatos[i]=(int)(Math.random()*100)+1;
            
       }         
             
        System.out.println(aiDatos);
tama=200;
 for (int i = 0; i < aiDatos.length; i++) {
            aiDatos[i]=(int)(Math.random()*100)+1;
            
       }   
        System.out.println(aiDatos);
        aiDatos[4]=5000;
        aiDatos[69]=500;
    }
    
}
