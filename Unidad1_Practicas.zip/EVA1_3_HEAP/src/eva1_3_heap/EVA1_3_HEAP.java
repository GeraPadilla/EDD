/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva1_3_heap;

/**
 *
 * @author Asus
 */
public class EVA1_3_HEAP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application/* */logic here
        int i=10;
        EVA1_3_HEAP Obj=new EVA1_3_HEAP();
        System.out.println(i);
        System.out.println(Obj);
        Obj=null;
    }
    
}
