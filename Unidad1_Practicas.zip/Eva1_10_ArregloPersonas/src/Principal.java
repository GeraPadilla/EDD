
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Asus
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Persona[] Arreglin = new Persona[3];
        Persona[] ArreglinCopia = new Persona[Arreglin.length];
        Scanner tecladin = new Scanner(System.in);
        System.out.println("arreglo original");
        for (int i = 0; i < Arreglin.length; i++) {
            Arreglin[i] = new Persona();
            System.out.println("Ingrese nombre");
            Arreglin[i].nombre = tecladin.nextLine();
            System.out.println("Ingrese apellido");
            Arreglin[i].apellido = tecladin.nextLine();
        }
        for (int i = 0; i < ArreglinCopia.length; i++) {
            ArreglinCopia[i] = new Persona();
            ArreglinCopia[i].nombre = Arreglin[i].nombre;
            ArreglinCopia[i].apellido = Arreglin[i].apellido;
        }
        for (int i = 0; i < Arreglin.length; i++) {
            System.out.println("Persona número " + i + " " + Arreglin[i].nombre + " " + Arreglin[i].apellido);
            System.out.println("Persona copiada número " + i + " " + ArreglinCopia[i].nombre + " " + ArreglinCopia[i].apellido);

        }
        System.out.println("La dirección del Arreglin es " + Arreglin);
        System.out.println("La dirección de la copia Arreglin, ArreglinCopia es " + ArreglinCopia);
        System.out.println("-------------------------------------------------------------------------");
        ImprimeArreglin(Arreglin);
        ImprimeArreglin(ArreglinCopia);
    }

    public static void ImprimeArreglin(Persona[] args) {
        for (int i = 0; i < args.length; i++) {
            System.out.println("Persona número " + i + " " + args[i].nombre + " " + args[i].apellido);

        }
    }
}

class Persona {

    String nombre, apellido;
}
