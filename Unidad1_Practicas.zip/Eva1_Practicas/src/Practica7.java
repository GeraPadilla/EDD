/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class Practica7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int pos, aux;
        int Arreglaso[]=new int[50];
        for (int i = 0; i < Arreglaso.length; i++) {
            Arreglaso[i]=(int) (Math.random()*100);
            pos = i;
            aux = (int) Arreglaso[i];
            while ((pos > 0) && (Arreglaso[pos - 1]) > aux) {
                Arreglaso[pos] = Arreglaso[pos - 1];
                pos--;
            }
            Arreglaso[pos] = aux;

        }
        for (int i = 0; i < Arreglaso.length; i++) {
            System.out.println(Arreglaso[i]+" ");
        }
        System.out.println("El menor es "+Arreglaso[0]+" y el mayor es "+Arreglaso[49]);
    }
    
}
