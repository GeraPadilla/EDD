/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class Practica4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double Matriz_A[][] = new double[5][5];
        double Matriz_B[][] = new double[5][5];
        double Matriz_C[][] = new double[5][5];
        for (int i = 0; i < Matriz_A.length; i++) {
            for (int j = 0; j < Matriz_A[i].length; j++) {
                Matriz_A[i][j] = (double) (Math.random() * 10);
                Matriz_B[i][j] = (double) (Math.random() * 10);
                Matriz_C[i][j] = Matriz_A[i][j] * Matriz_B[i][j];
            }
        }
        imprimirArreglo(Matriz_A);
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
        imprimirArreglo(Matriz_B);
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
        imprimirArreglo(Matriz_C);
    }

    public static void imprimirArreglo(double[][] args) {
        System.out.println("");
        for (int i = 0; i < args.length; i++) {
            for (int j = 0; j < args[i].length; j++) {
                System.out.print("[" + args[i][j] + "]");
            }
            System.out.println("");
        }

    }
}
