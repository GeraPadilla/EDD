/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class Practica3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int matrix[][] = new int[5][5];
        int matrixcopia[][] = new int[5][5];
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                matrix[i][j] = (int) (Math.random() * 100);
                System.out.print("[" + matrix[i][j] + "]");
            }
            System.out.println("");
        }

        System.out.println("-----------------------------------");
        for (int i = matrixcopia.length - 1; i >= 0; i--) {
            for (int j = matrixcopia[i].length - 1; j >= 0; j--) {
                matrixcopia[i][j] = matrix[i][j];
                System.out.print("[" + matrixcopia[i][j] + "]");
            }
            System.out.println("");
        }

    }

}
