
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Asus
 */
public class Practica1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic heres

        Scanner tecladin = new Scanner(System.in);
        System.out.println("¿De cuántos datos quieres el arreglo?: ");
        double Personas[] = new double[tecladin.nextInt()];
        for (int i = 0; i < Personas.length; i++) {
            System.out.println("Ingrese el valor número " + (i + 1));
            Personas[i] = tecladin.nextDouble();
        }
        double promedio;
        double suma = 0;
        for (int i = 0; i < Personas.length; i++) {
            suma = suma + Personas[i];
        }
        promedio = suma / Personas.length;

        double varianza = 0;
        double sumatoria;
        for (int i = 0; i < Personas.length; i++) {
            sumatoria = Math.pow(Personas[i] - promedio, 2);
            varianza = varianza + sumatoria;
        }
        varianza = varianza / (Personas.length - 1);
        double desviacion = Math.sqrt(varianza);
        System.out.println("La desviación estándar es " + desviacion);
        System.out.println("El promedio es " + promedio);
        int pos, aux;
        for (int i = 0; i < Personas.length; i++) {
            pos = i;
            aux = (int) Personas[i];
            while ((pos > 0) && (Personas[pos - 1]) > aux) {
                Personas[pos] = Personas[pos - 1];
                pos--;
            }
            Personas[pos] = aux;

        }
        for (int i = 0; i < Personas.length; i++) {
            System.out.print(Personas[i] + " ,");
        }
        System.out.println("");

        if (Personas.length % 2 == 0) {
            System.out.println("La mediana es " + (Personas[Personas.length / 2] + Personas[((Personas.length / 2) - 1)]) / 2);
        } else {
            System.out.println("La mediana es " + Personas[Personas.length / 2]);
        }
    }

}
