/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int aiDatos[];
        int aiCopia[];
        aiCopia = new int[10];
        aiDatos = new int[10];
        for (int i = 0; i < aiDatos.length; i++) {
            aiDatos[i] = (int) (Math.random() * 100) + 1;
        }
        for (int i = 0; i < aiDatos.length; i++) {
            aiCopia[i] = aiDatos[i];
        }
        imprimirArreglo(aiDatos);
        imprimirArreglo(aiCopia);
        System.out.println(aiCopia);
        System.out.println(aiDatos);
        aiDatos[0]=9999;
        imprimirArreglo(aiDatos);
        System.out.println(aiCopia);
        System.out.println(aiDatos);
    }

    public static void imprimirArreglo(int[] args) {
        System.out.println("");
        for (int i = 0; i < args.length; i++) {
            System.out.print("["+args[i]+"]");
        }
        System.out.print("");
    }

}
