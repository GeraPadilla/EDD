/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class Principiante5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) { //principiante n5
        // TODO code application logic here
        int[] ge = new int[15];
        int pareja;
        for (int i = 0; i < ge.length; i++) {
            pareja = (int) (Math.random() * 100) + 1;
            if (i%2!=0) {
                 if (pareja % 2 == 0) {
                ge[i] = pareja;
            }
            for (int j = 0; j < i; j++) {
                if (ge[i] == ge[j]) {
                    i--;
                }
            }
           
            }
            if (i%2==0) {
                ge[i]=(int) (Math.random() * 100) + 1;
            }
            
        }
        for (int i : ge) {
            System.out.println(i);
        }
    }

}
