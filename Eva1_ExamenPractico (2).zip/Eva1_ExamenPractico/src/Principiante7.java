
import java.util.Arrays;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Asus
 */
public class Principiante7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int arr[] = new int[15];
        int valor = 0;
        Scanner tecladin = new Scanner(System.in);

        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int) (Math.random() * 20);
            System.out.print(arr[i] + "-");

        }
        System.out.println("");
////////////////////////////////////////////////
        System.out.println("limite A");
        int a = tecladin.nextInt();
        System.out.println("limite B");
        int b = tecladin.nextInt();
        int[] eo = new int[(b+1) - a];
                //Arrays.copyOfRange(arr, a, b);
        int aux = 0;
        for (int i = a; i < b; i++) {
            eo[aux] = arr[i];
            aux++;
        }
        /*for (int i = 0; i < eo.length; i++) {
            System.out.print(eo[i]+" ");
        }*/
        int x = 0;
        int[] orasi = new int[eo.length];

        for (int i = 0; i < eo.length; i++) {
            if (eo[i] % 2 == 0) {

                orasi[i] = eo[i];
                System.out.print(orasi[i] );
            } else {
                System.out.print(" ");
            }
            System.out.print("-");
        }

    }

}
