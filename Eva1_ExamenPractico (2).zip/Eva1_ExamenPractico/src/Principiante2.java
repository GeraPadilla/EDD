
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Asus
 */
public class Principiante2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) { //principiante n2
        // TODO code application logic here
        
        int[] Matriz1 = new int[10];
        int[] Matriz2 = new int[10];
        Scanner tecla = new Scanner(System.in);
        System.out.println("Valores para el arreglo 1");
        for (int i = 0; i < Matriz1.length; i++) {
            System.out.println("Inserte el valor número " + (i + 1) + " del arreglo 1");
            Matriz1[i] = tecla.nextInt();
            tecla.nextLine();
        }
        System.out.println("\nValores para el arreglo 2");
        for (int i = 0; i < Matriz2.length; i++) {
            System.out.println("Inserte el valor número " + (i + 1) + " del arreglo 2");
            Matriz2[i] = tecla.nextInt();
            tecla.nextLine();
        }
        int acum = 0;
        for (int i = 0; i < Matriz1.length && i < Matriz2.length; i++) {

            if (Matriz1[i] == Matriz2[i]) {
                acum++;
            }
        }
        System.out.println("--------------------------------------------");
        System.out.print("Matriz 1:[");
        for (int i = 0; i < Matriz1.length; i++) {

            System.out.print(Matriz1[i]);
            if (i == (Matriz1.length) - 1) {
                System.out.println("]");
            } else {
                System.out.print(", ");
            }
        }
        System.out.println("--------------------------------------------");
        System.out.print("Matriz 2:[");
        for (int i = 0; i < Matriz2.length; i++) {

            System.out.print(Matriz2[i]);
            if (i == (Matriz2.length) - 1) {
                System.out.println("]");
            } else {
                System.out.print(", ");
            }
        }
        if (acum == Matriz1.length && acum == Matriz2.length) {
            System.out.println("Ambos arreglos son iguales");
        } else {
            System.out.println("Los arreglos son desiguales");
        }
    }

}
