
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class Intermedio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       int[] Matriza = new int[15];
        int aux;
        Scanner kb = new Scanner(System.in);
        for (int i = Matriza.length-1; i >= 0; i--) {/*Se usa el for de esta manera para que se impriman los valores desde la derecha*/
        System.out.println("Valores");
        Matriza[i]= kb.nextInt();kb.nextLine();
        //Ordenador en burbuja, antes de imprimir los datos
            for (int j = 0; j < Matriza.length; j++) {
                for (int k = 0; k < Matriza.length - 1; k++) {
                    if (Matriza[k] > Matriza[k + 1]) {
                        aux = Matriza[k];
                        Matriza[k] = Matriza[k + 1];
                        Matriza[k + 1] = aux;
                        }
                    }
                }
            //Se imprimen los espacios que aún faltan por llenar
            for (int j = 0; j < i; j++) {
                System.out.print("[ ] ");
            }
            /*se imprimen los valores del arreglo a la derecha de
            los espacios libres, ya ordenados de forma creciente*/
            for (int j = i ; j < Matriza.length; j++) {
                System.out.print("["+Matriza[j]+"] ");
            }
            System.out.println("");

        }
    }
    
}
