
class Exa2 {

    public static void main(String[] args) {
      /*  int arreglin[] = new int[15];
        
        for (int i = 0; i < arreglin.length; i++) {
            arreglin[i] = (int) (Math.random() * 100) + 1;
        }
        int dim = arreglin.length;
        contin(arreglin,arreglaso, dim);*/
    }

    /*public static void contin(int arreglin[],int arreglaso[][], int dim) {
        boolean condicional[] = new boolean[dim];

        for (int i = 0; i < condicional.length; i++) {
            condicional[i] = false;
        }

        for (int i = 0; i < dim; i++) {

            // Skip this element if already processed 
            if (condicional[i] == true) {
                continue;
            }

            // Count frequency 
            int repet = 1;
            for (int j = i + 1; j < dim; j++) {
                if (arreglin[i] == arreglin[j]) {
                    condicional[j] = true;
                    repet++;
                
                }
            }
            System.out.println("["+arreglin[i] + "]" + repet);
        }
    }

// Driver code*/ 
}